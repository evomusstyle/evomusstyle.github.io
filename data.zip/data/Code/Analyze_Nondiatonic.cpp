#include<fstream>
#include<iostream>
#include<cmath>
#include<string>
#include<sstream>
#include<vector>
#include<algorithm>
#include"stdio.h"
#include"stdlib.h"
#include"PianoRoll_v170503.hpp"

using namespace std;

int main(int argc, char** argv){
	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;

	if(argc!=2){cout<<"Error in usage: $./this in.mid"<<endl; return -1;}

	string infile=string(argv[1]);//MIDI

	PianoRoll pr;
	pr.ReadMIDIFile(infile);
	vector<int> pc,pci;
	for(int n=0;n<pr.evts.size();n+=1){
		pc.push_back(pr.evts[n].pitch%12);
	}//endfor n
	for(int n=1;n<pc.size();n+=1){
		pci.push_back((pc[n]-pc[n-1]+24)%12);
	}//endfor n
	for(int n=pci.size()-1;n>=0;n-=1){
		if(pci[n]==0){pci.erase(pci.begin()+n);}
	}//endfor n

	d[0]=0;
	d[1]=0;

	for(int n=1;n<pci.size();n+=1){
		d[0]+=1;
		if(
			(pci[n-1]==1&&pci[n]==1)
			|| (pci[n-1]==1&&pci[n]==3)
			|| (pci[n-1]==1&&pci[n]==8)
			|| (pci[n-1]==1&&pci[n]==10)
			|| (pci[n-1]==2&&pci[n]==11)
			|| (pci[n-1]==3&&pci[n]==1)
			|| (pci[n-1]==3&&pci[n]==8)
			|| (pci[n-1]==4&&pci[n]==4)
			|| (pci[n-1]==4&&pci[n]==9)
			|| (pci[n-1]==4&&pci[n]==11)
			|| (pci[n-1]==8&&pci[n]==1)
			|| (pci[n-1]==8&&pci[n]==3)
			|| (pci[n-1]==8&&pci[n]==8)
			|| (pci[n-1]==9&&pci[n]==4)
			|| (pci[n-1]==9&&pci[n]==11)
			|| (pci[n-1]==10&&pci[n]==1)
			|| (pci[n-1]==11&&pci[n]==2)
			|| (pci[n-1]==11&&pci[n]==4)
			|| (pci[n-1]==11&&pci[n]==9)
			|| (pci[n-1]==11&&pci[n]==11)
		){
			d[1]+=1;
		}//endif
	}//endfor n

cout<<d[1]/d[0]<<endl;

	return 0;
}//end main
