#! /bin/bash

g++ Analyze_Tritone.cpp -o Analyze_Tritone
g++ Analyze_Nondiatonic.cpp -o Analyze_Nondiatonic
g++ Analyze_RareRhythm.cpp -o Analyze_RareRhythm

