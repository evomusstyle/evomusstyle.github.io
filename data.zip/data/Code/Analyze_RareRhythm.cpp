#include<fstream>
#include<iostream>
#include<cmath>
#include<string>
#include<sstream>
#include<vector>
#include<algorithm>
#include"stdio.h"
#include"stdlib.h"
#include"Fmt3x_v170225.hpp"

using namespace std;

int main(int argc, char** argv){
	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;

	if(argc!=2){cout<<"Error in usage: $./this in.xml"<<endl; return -1;}

	string infile=string(argv[1]);//MusicXML

	Fmt1x fmt1x;
	fmt1x.ReadMusicXML(infile);
	for(int n=fmt1x.evts.size()-1;n>=0;n-=1){
		if( !(fmt1x.evts[n].part==1 && fmt1x.evts[n].staff==1 && fmt1x.evts[n].voice==1) ){
			fmt1x.evts.erase(fmt1x.evts.begin()+n);
		}//endif
	}//endfor n

	vector<int> nv;
	int curNV=0;
	for(int n=0;n<fmt1x.evts.size();n+=1){
		if(fmt1x.evts[n].eventtype=="chord"){
			curNV+=fmt1x.evts[n].dur;
			if(fmt1x.evts[n].tieinfo>=2){
			}else{
				nv.push_back(curNV);
				curNV=0;
			}//endif
		}//endif
	}//endfor n

	d[0]=0;
	d[1]=0;
	for(int m=1;m<nv.size();m+=1){
		d[0]+=1;
		if( !(
			nv[m]==nv[m-1]
			||nv[m]==2*nv[m-1]||2*nv[m]==nv[m-1]
			||2*nv[m]==3*nv[m-1]||3*nv[m]==2*nv[m-1]
			||nv[m]==3*nv[m-1]||3*nv[m]==nv[m-1]
			||nv[m]==4*nv[m-1]||4*nv[m]==nv[m-1]
			||nv[m]==6*nv[m-1]||6*nv[m]==nv[m-1]
		) ){
			d[1]+=1;
		}//endif
	}//endfor m

cout<<d[1]/d[0]<<endl;

	return 0;
}//end main
