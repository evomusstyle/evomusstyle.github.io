The contents of the data are described in the following.


In the folder “ClassicalMusic”, the list of musical pieces used for the analysis are given in list_Classic_all_WithRef.txt, where from the left to right the columns indicate (piece ID), (birth year of the composer), composer, and (original file name).

The list of composers and their birth years are also given in list_composers_time.txt.

In RawData_Tritone.txt the raw tritone features extrated from individual musical pieces are given. The statistics for the time periods of 25 years are given in RawData_Tritone_FineSmooth.txt, where from left to right the columns indicate (first year of each time period), (number of pieces in the time period), (mean value), (standard deviation), and (ratio of mean and standard deviation). These files were used for Figs. 1(a) and 1(b).

Similarly the raw statistics data for the non-diatonic feature is given in RawData_NondiatonicMotion.txt and RawData_NondiatonicMotion_FineSmooth.txt. These files were used for Figs. 1(a) and 1(b) in Supplemental Material.

In dyn_Tritone_RealData.txt the statistics of the tritone feature for the time periods of 50 years obtained from RawData_Tritone.txt are given. From left to right the columns indicate (middle year of each time period), (mean value), (standard deviation), and (ratio of mean and standard deviation). The 4 files dyn_Tritone_BetaSCE_0-0.05.txt, dyn_Tritone_BetaSCE_0.12-0.07.txt, dyn_Tritone_LogPotential_0.41.txt, and dyn_Tritone_LogPotential_1.11.txt are the results of the model predictions. These files were used for Fig. 4(a) in the main text and Fig. 6(a) in Supplemental Material.

In exactly the same formats, dyn_Nondiatonic_RealData.txt and 3 files dyn_Nondiatonic_BetaSCE_0-0.05.txt, dyn_Nondiatonic_LogPotential_0.39.txt, and dyn_Nondiatonic_LogPotential_0.41.txt describe the data for the non-diatonic features used for Fig. 4(b) in the main text and Fig. 6(b) in Supplemental Material.

In dyn_Bigram_RealData.txt, the statistical data for bigarm features of pitch-class intervals in time periods of 100 years used for Fig. 1(c) are given. The first column shows the middle year of each time period. The following columns show the mean and standard deviations for the 121 bigram features.


In the folder “Enka”, the list of musical pieces used for the analysis are given in list_Enka_1960.txt, where from the left to right the columns indicate (piece ID) and (composed year).

In RawData_Rhythm.txt the frequencies of rare rhythms extrated from individual musical pieces are given, where from left to right the columns indicate (piece ID), (composed year), and (value of the feature).

In dyn_Enka_RareRhythm_RealData.txt the statistics of the rare rhythm feature for the time periods of 10 years obtained from RawData_Rhythm.txt are given. From left to right the columns indicate (middle year of each time period), (mean value), (standard deviation), and (ratio of mean and standard deviation). The two files dyn_Enka_RareRhythm_BetaSCE_0.9-0.2.txt and dyn_Enka_RareRhythm_LogPotential_-0.26.txt are the results of the model predictions. These files were used for Fig. 4(c). 

In the folder “Code”, the source code used for extracting the musical features is given. The compile commands are listed in compile.sh. Analyze_Tritone and Analyze_Nondiatonic take a standard MIDI file as input and Analyze_RareRhythm takes a MusicXML file as input. The outputs are the corresponding probability values.







